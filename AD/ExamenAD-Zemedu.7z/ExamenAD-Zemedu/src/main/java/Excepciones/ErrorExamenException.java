package Excepciones;

public class ErrorExamenException extends Exception{
       
    public ErrorExamenException(String message){
        super(message);
    } 
}
