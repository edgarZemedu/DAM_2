package App;

import static App.OperacionesExamen.pasarObjetos;
import ConexionSingleton.*;
import Excepciones.*;
import Libreria.*;
import POJO.*;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;
import javax.management.OperationsException;

/**
 *
 * @author a18zemedufc
 */
public class Main {

    static Scanner sc = new Scanner(System.in);
    static ArrayList<Alumnado> listAlumnos = new ArrayList<Alumnado>();

    public static void main(String[] args) {

        boolean fin = false;
        String resultado = "";
        String nombre = "";
        int edad = 0;
        String cadenaConexion = "jdbc:sqlite:BD\\biblioteca";

        try (Connection miConexion = ConexionSingleton.getConnection(cadenaConexion, "admin", "admin");) {

            do {

                switch (pintarMenu()) {
                    case 1://mostrar el contenido del xml
                        try {
                           OperacionesExamen.verXML(miConexion);
                            System.out.println("Operación realizada con éxito”");
                        } catch (ErrorExamenException ex) {
                            System.out.println(ex.getMessage());
                        }
                    break;

                    case 2:
                        try {
                            pasarObjetos(miConexion);
                            System.out.println("Operación realizada con éxito”");
                        } catch (ErrorExamenException ex) {
                            System.out.println(ex.getMessage());
                        }
                        break;
                    case 3://
                        System.out.println("Operación realizada con éxito”");
                        break;
                    case 4://
                        System.out.println("Operación realizada con éxito”");
                        break;
                    case 5:
                        System.out.println("Operación realizada con éxito”");
                        break;
                    case 6:
                        System.out.println("Operación realizada con éxito”");
                        break;
                    case 7:
                        System.out.println("Hasta luego!!!");
                        fin = true;
                }

            } while (!fin);

        } catch (SQLException e) {
            System.out.println("Se ha producido una excepcion " + e.getMessage()
                    + " El programa se cerrará. /n Consulte con el responsable");
        } finally {//Cerrar conexión y flujo de entrada estándar
            sc.close();
        }

    }

    static byte pintarMenu() {
        byte opcion = 0;
        boolean correcta;

        ArrayList<String> misOpciones;
        misOpciones = new ArrayList<String>() {
            {
                add("MOstrar por pantalla el contenido del fichero XML Alumnado");
                add("Pasar información de fichero XML a objetos de la clase Alumnado");
                add("Crear una tabla llamada Alumnado en la BD(CURSO.DB)");
                add("Transladar la informacióon en el ArrayList GrupoAlumnado a la tabla tabla Alumnno");
                add("Mostrar Tabla");
                add("Convertir la informacion almacenada de la tabla en un xml llamado CURSO2021.XML");
                add("FINALIZAR");
            }
        };

        /*La clase Menu permite imprimir el menú a partir de los datos de un ArrayList<String>
            y utilizar métodos para control de rango*/
        Menu miMenu = new Menu(misOpciones);

        System.out.println("\n\n*************************GESTION DE BIBLIOTECA*************************************");
        /* Solo sale del While cuando se selecciona una opción correcta en rango y tipo*/
        do {
            miMenu.printMenu();

            /*La clase ControlData permite hacer un control de tipo leído*/
            try {
                opcion = ControlData.lerByte(sc);
                /*miMenu.rango() lanza una excepción propia en el caso de que 
                el parámetro opcion esté fuera del rango posible */
                miMenu.rango(opcion);
                correcta = true;
            } catch (NumeroFueraRangoException e) {//Excepción personalizada
                System.out.println(e.getMessage());
                correcta = false;
            }

        } while (!correcta);

        return opcion;
    }

}
