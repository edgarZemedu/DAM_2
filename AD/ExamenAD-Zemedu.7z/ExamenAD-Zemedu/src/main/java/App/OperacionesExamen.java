/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package App;

import Excepciones.ErrorExamenException;
import POJO.Alumnado;
import java.io.File;
import java.sql.Connection;
import java.util.ArrayList;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 *
 * @author a18zemedufc
 */
public class OperacionesExamen {

    public static void verXML(Connection laConexion) throws ErrorExamenException {
        String mensaje = "";
        try {
            File archivo = new File("Alumnado.xml");
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder documentBuilder = dbf.newDocumentBuilder();
            Document document = documentBuilder.parse(archivo);
            document.getDocumentElement().normalize();
            String eleRaiz = document.getDocumentElement().getNodeName();
            System.out.println("Elemento raiz:" + eleRaiz);
            Node node = document;
            mostrarDOM_Recursivo(node, "");

        } catch (Exception e) {
            //En el caso de que no se pueda ejecutar, lo más probable es que sea porque ya están creadas
            mensaje = "No se ha podido realizar la visualización \n";
            throw new ErrorExamenException(mensaje + "\n" + e.getMessage());
        }
    }

    static void mostrarDOM_Recursivo(Node nodo, String ind) {

        switch (nodo.getNodeType()) {
            case Node.DOCUMENT_NODE:
                System.out.println("\n<xml version=\"1.0\">");
                Document doc = (Document) nodo;
                mostrarDOM_Recursivo(doc.getDocumentElement(), "");
                break;

            case Node.ELEMENT_NODE:
                String nombre = nodo.getNodeName();
                System.out.print(ind + "<" + nombre);
                NamedNodeMap ats = nodo.getAttributes();
                for (int i = 0; i < ats.getLength(); i++) {
                    mostrarDOM_Recursivo(ats.item(i), "");
                }

                System.out.println(">");
                NodeList hijos = nodo.getChildNodes();
                if (hijos != null) {
                    for (int i = 0; i < hijos.getLength(); i++) {
                        mostrarDOM_Recursivo(hijos.item(i), ind + "   ");
                    }
                }
                System.out.println(ind + "</" + nombre + ">");
                break;

            case Node.ATTRIBUTE_NODE:
                Attr atributo = (Attr) nodo;
                System.out.print(" " + atributo.getNodeName()
                        + " = " + atributo.getNodeValue());
                break;

            case Node.TEXT_NODE:
                String texto = nodo.getTextContent();
                System.out.println("        " + texto);
        }

    }

    public static String pasarObjetos(Connection laConexion) throws ErrorExamenException {
        String mensaje = "";
        ArrayList<Alumnado> listAlumnos = null;
        Alumnado a = null;
        try {
            File archivo = new File("Alumnados.xml");
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder documentBuilder = dbf.newDocumentBuilder();
            Document document = documentBuilder.parse(archivo);
            document.getDocumentElement().normalize();
            String eleRaiz = document.getDocumentElement().getNodeName();
            NodeList listaNede = document.getChildNodes();

            for (int temp = 0; temp < listaNede.getLength(); temp++) {
                Node nodo = listaNede.item(temp);
                if (nodo.getNodeName().equalsIgnoreCase("nombre") ) {
                    a.setNombre(nodo.getNodeValue());
                    listAlumnos.set(temp, a);
                }
                
                if (nodo.getNodeName().equalsIgnoreCase("edad") ) {
                    a.setEdad(Integer.parseInt(nodo.getNodeValue()));
                    listAlumnos.set(temp, a);
                }
            }
        } catch (Exception e) {
            //En el caso de que no se pueda ejecutar, lo más probable es que sea porque ya están creadas
            mensaje = "No se ha podido realizar la operación de alta BD\n";
            throw new ErrorExamenException(mensaje + "\n" + e.getMessage());
        }
        return mensaje;
    }
}
