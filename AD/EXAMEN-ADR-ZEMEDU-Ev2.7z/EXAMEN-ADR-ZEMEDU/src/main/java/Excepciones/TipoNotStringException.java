/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Excepciones;

/**
 *
 * @author Esther Ferreiro
 */
public class TipoNotStringException extends Exception {

    public TipoNotStringException() {
        super ("Error. Debe introducir unha cadea de caracteres");  
    }
    
}
