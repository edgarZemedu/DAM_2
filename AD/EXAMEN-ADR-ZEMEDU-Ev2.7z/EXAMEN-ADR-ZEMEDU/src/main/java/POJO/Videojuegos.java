/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package POJO;

/**
 *
 * @author a18zemedufc
 */
public class Videojuegos {
    
    private int codigo;
    private String nombre;
    private int anno;
    private double ventas;

    public Videojuegos() {
    }

    public Videojuegos(String nombre, int anno, double ventas) {
        this.nombre = nombre;
        this.anno = anno;
        this.ventas = ventas;
    }

    public Videojuegos(int codigo, String nombre, int anno, double ventas) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.anno = anno;
        this.ventas = ventas;
    }

    
    
    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getAnno() {
        return anno;
    }

    public void setAnno(int anno) {
        this.anno = anno;
    }

    public double getVentas() {
        return ventas;
    }

    public void setVentas(double ventas) {
        this.ventas = ventas;
    }

    @Override
    public String toString() {
        return "Videojuegos{" + "codigo=" + codigo + ", nombre=" + nombre + ", anno=" + anno + ", ventas=" + ventas + '}';
    }
    
    
    
}
