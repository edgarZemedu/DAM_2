/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package OperacionesExamen;

import Excepciones.ErrorExamenException;
import POJO.Videojuegos;
import POJO.listaVideosjuegos;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Text;

/**
 *
 * @author a18zemedufc
 */
public class Operacion {

    static ArrayList<Videojuegos> lista = new ArrayList<Videojuegos>();

    public static String crearBD(Connection laConexion) throws ErrorExamenException {
        String mensaje;
        try {
            Statement elStatement = laConexion.createStatement();

            elStatement.execute("CREATE TABLE IF NOT EXISTS videojuegos "
                    + "(CODIGO INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,"
                    + " NOMBRE VARCHAR(50) NOT NULL,"
                    + " ANNO INTEGER,"
                    + " VENTAS DOUBLE);");
            mensaje = "Tabla VIDEOJUEGOS creada correctamente";

        } catch (SQLException ex) {
            //En el caso de que no se pueda ejecutar, lo más probable es que sea porque ya están creadas
            //El mensaje lo tomo hasta e primer \n pues es donde indica la información útil
            mensaje = "No se ha podido realiazar la operación\n"
                    + ex.getMessage();
            throw new ErrorExamenException(mensaje);
        }
        return mensaje;

    }

    public static String altaVideojuego(Connection laConexion, String nombre, int anno, double ventas) throws ErrorExamenException {
        String mensaje = "";
        try {
            // Preparamos la consulta
            // El parámetro Statement.RETURN_GENERATED_KEYS permite recuperar el ID autogenerado tras el INSERT
            PreparedStatement elPrepareStatement = laConexion.prepareStatement("INSERT INTO videojuegos (nombre,anno,ventas) VALUES (?,?,?)", Statement.RETURN_GENERATED_KEYS);
            //Asignamos los parámetros
            elPrepareStatement.setString(1, nombre);
            elPrepareStatement.setInt(2, anno);
            elPrepareStatement.setDouble(3, ventas);

            //Ejecutamos la operación de inserción en la tabla 
            int affectedRows = elPrepareStatement.executeUpdate();
            mensaje = "Se ha agregado " + affectedRows + " videojuegos a la Tabla";
        } catch (SQLException e) {
            //En el caso de que no se pueda ejecutar, lo más probable es que sea porque ya están creadas
            mensaje = "No se ha podido realizar la operación de alta solicitada\n";
            throw new ErrorExamenException(mensaje + "\n" + e.getMessage());
        }
        return mensaje;
    }

    public static String almacenarSQLite(Connection laConexion) throws ErrorExamenException {

        almacenarObjeto();

        for (Videojuegos i : lista) {
            Operacion.altaVideojuego(laConexion, i.getNombre(), i.getAnno(), i.getVentas());
        }

        return "Datos almacenados correctemente en la tabla";
    }

    public static ArrayList<Videojuegos> almacenarObjeto() {
        Videojuegos v;

        v = new Videojuegos("Tetrix", 1984, 170);
        lista.add(v);
        v = new Videojuegos("Super Mario Bros", 1985, 140);
        lista.add(v);
        v = new Videojuegos("Sonic", 1991, 15);
        lista.add(v);
        v = new Videojuegos("FIFA", 1993, 94);
        lista.add(v);
        v = new Videojuegos("The Legend of Zelda", 1998, 8);
        lista.add(v);

        return lista;
    }

    public static void mostrarObjetos() {
        almacenarObjeto();
        if (lista.isEmpty()) {
            System.out.println("Error,no has metido los datos en el array");
        } else {
            for (Videojuegos v : lista) {
                System.out.println("Mostrar Videojuegos --> ");
                System.out.println("" + v.toString());
            }
        }

    }

    public static String pasarSQLiteAXML80(Connection miConexion) throws ErrorExamenException {

        String resultado = "";
        // Preparamos la consulta
        try {
            /**
             * *Creamos el elemento raíz del DOM (videjuegos)**
             */
            Document documento = DocumentBuilderFactory.newInstance().newDocumentBuilder().
                    getDOMImplementation().createDocument(null, "Videojuegos", null);
            documento.setXmlVersion("1.0");//Asignar la versión de XML 

            Element elemento = crearElemento("videojuego", documento);

            for (Videojuegos v : lista) {
                if (v.getAnno() < 1990) {
                    crearSubElemento("nombre", v.getNombre(), elemento, documento);
                    crearSubElemento("anno", String.valueOf(v.getAnno()), elemento, documento);
                }
            }
            crearFicheroXML(documento, "VIDEOJUEGOS-80.xml");
            resultado = "Se ha creado el fichero VIDEOJUEGOS-80.xml correctamente";

        } catch (ParserConfigurationException | TransformerException e) {
            //Envio a la excepción propia el mensaje de la excepción que se produzca aquí
            throw new ErrorExamenException(e.getMessage());
        }
        return resultado;

    }

    public static String pasarSQLiteAXML90(Connection miConexion) throws ErrorExamenException {

        String resultado = "";
        // Preparamos la consulta
        try {
            /**
             * *Creamos el elemento raíz del DOM (videjuegos)**
             */
            Document documento = DocumentBuilderFactory.newInstance().newDocumentBuilder().
                    getDOMImplementation().createDocument(null, "Videojuegos", null);
            documento.setXmlVersion("1.0");//Asignar la versión de XML 

            Element elemento = crearElemento("videojuego", documento);

            for (Videojuegos v : lista) {
                if (v.getAnno() > 1990) {
                    crearSubElemento("nombre", v.getNombre(), elemento, documento);
                    crearSubElemento("anno", String.valueOf(v.getAnno()), elemento, documento);
                }
            }
            crearFicheroXML(documento, "VIDEOJUEGOS-90.xml");
            resultado = "Se ha creado el fichero VIDEOJUEGOS-90.xml ";

        } catch (ParserConfigurationException | TransformerException e) {
            //Envio a la excepción propia el mensaje de la excepción que se produzca aquí
            throw new ErrorExamenException(e.getMessage());
        }
        return resultado;

    }

    static Element crearElemento(String nombreElemento, Document documento) {
        Element elemento = documento.createElement(nombreElemento);
        //Enlazamos el elemento raíz al documento creado
        documento.getDocumentElement().appendChild(elemento);
        return elemento;
    }

    static void crearSubElemento(String hijo, String valor, Element padre, Document documento) {
        //Creamos el elemento
        Element elemento = documento.createElement(hijo);
        //Le damos valor al elemento creado
        Text texto = documento.createTextNode(valor);
        //Elazamos el hijo con el padre
        padre.appendChild(elemento);
        //Le damos valor al elemento creado
        elemento.appendChild(texto);
    }

    static void crearFicheroXML(Document documento, String nombreFichero) throws TransformerException {
        /*Se determina el elemento Document (árbol DOM) que tiene la información
        que queremos pasar al fichero de texto xml*/
        Source sourceDOM = new DOMSource(documento);
        /*Se crea un Stream que tiene como destino el fichero de texto XML que se quiere crear
        a partir del árbol DOM*/
        File elFicheroXML = new File(nombreFichero);
        Result resultadoFichero = new StreamResult(elFicheroXML);
        /*Obtenemos una instancia de la clase Transformer que permitirá pasar el árbol DOM
        a un fichero XML*/
        Transformer transformer = TransformerFactory.newInstance().newTransformer();
        transformer.transform(sourceDOM, resultadoFichero);
        
    }

    public static String leeTodosLosCaracteres80() throws ErrorExamenException {
        String mensaje = "";
        File elFicheroXML = new File("VIDEOJUEGOS-80.xml");
        //Como buffer voy a utilizar un StringBuilder 
        //que permite almacenar una cadena
        StringBuilder bufO = new StringBuilder();
        //Creo un FileReader a partir de un fichero de texto y codifico cada carazter con UTF-8
        try (
                Reader miFileReader = new FileReader(elFicheroXML)) {
            //Creo un búfer de caracteres para los datos de entrada
            char[] bufI = new char[10];
            int n;
            //Voy leyendo el flujo de entrada de datos y guardo cada lectura en bufI
            while ((n = miFileReader.read(bufI)) != -1) {
                bufO.append(bufI);
                //bufI = new char[10]; ;
            }
        } catch (IOException ex) {
            mensaje = ex.getMessage();
            throw new ErrorExamenException(mensaje);
        }
        System.out.println(bufO);
        
        return mensaje;
    }
    public static String leeTodosLosCaracteres90() throws ErrorExamenException {
        String mensaje = "";
        File elFicheroXML = new File("VIDEOJUEGOS-90.xml");
        //Como buffer voy a utilizar un StringBuilder 
        //que permite almacenar una cadena
        StringBuilder bufO = new StringBuilder();
        //Creo un FileReader a partir de un fichero de texto y codifico cada carazter con UTF-8
        try (
                Reader miFileReader = new FileReader(elFicheroXML)) {
            //Creo un búfer de caracteres para los datos de entrada
            char[] bufI = new char[10];
            int n;
            //Voy leyendo el flujo de entrada de datos y guardo cada lectura en bufI
            while ((n = miFileReader.read(bufI)) != -1) {
                bufO.append(bufI);
                //bufI = new char[10]; ;
            }
        } catch (IOException ex) {
            mensaje = ex.getMessage();
            throw new ErrorExamenException(mensaje);
        }
        System.out.println(bufO);

        return mensaje;
    }

}
