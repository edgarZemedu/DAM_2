/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package App;

import Conexion.ConexionSingleton;
import Excepciones.ErrorExamenException;
import Excepciones.NumeroFueraRangoException;
import Libreria.ControlData;
import Libreria.Menu;
import OperacionesExamen.Operacion;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author a18zemedufc
 */
public class NewMain {

    static Scanner sc = new Scanner(System.in);

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        boolean finalizar = false;
        String mensaje = "";
        String cadenaConexion = "jdbc:sqlite:BD\\juegos.db";

        //Establece la conexión con una base de datos SQLite.
        //No es necesario cerrar la conexión al usar try con recursos
        try (Connection laConexion = ConexionSingleton.getConnection(cadenaConexion)) {

            do {
                switch (pintarMenu()) {
                    case 1://Crear una tabla de videojuegos
                        try {
                        mensaje = Operacion.crearBD(laConexion);
                        System.out.println(mensaje);
                    } catch (ErrorExamenException ex) {
                        System.out.println("=> " + ex.getMessage());
                    }
                    break;

                    case 2://Crear una lista de objetos de los videojuegos de la tabla videojuegos                        
                        Operacion.mostrarObjetos();
                        break;

                    case 3://Pasar la información de la lista a ficheros XML por década
                        try {
                        mensaje = Operacion.pasarSQLiteAXML80(laConexion);
                        System.out.println(mensaje);
                        mensaje = Operacion.pasarSQLiteAXML90(laConexion);
                        System.out.println(mensaje);
                    } catch (ErrorExamenException ex) {
                        System.out.println(ex.getMessage());
                    }
                    break;

                    case 4: //Consultar fichero XML
                        System.out.println("Introduzca la década que se quiere consultar(80 o 90)");
                        int decada = sc.nextInt();
                        if (decada < 80 || decada > 99) {
                            System.out.println("Error con la entrada de datos");
                        } else {
                            if (decada >= 80 || decada < 90) {
                                try {
                                    mensaje = Operacion.leeTodosLosCaracteres80();
                                    System.out.println(mensaje);
                                } catch (ErrorExamenException ex) {
                                    System.out.println(ex.getMessage());
                                }
                            }
                            if (decada >= 90) {
                                try {
                                    mensaje = Operacion.leeTodosLosCaracteres90();
                                    System.out.println(mensaje);
                                } catch (ErrorExamenException ex) {
                                    System.out.println(ex.getMessage());
                                }
                            }
                        }
                        break;

                    case 5:
                        System.out.println("Hasta luego!!!");
                        //Cerrar el Scanner
                        sc.close();
                        finalizar = true;
                }
            } while (!finalizar);
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    /**
     * Dibuja un menú en la consola a partir con unas opciones determinadas
     */
    static byte pintarMenu() {
        byte opcion = 0;
        boolean correcta;

        ArrayList<String> misOpciones = new ArrayList<String>() {
            {
                add("Crear una tabla de videojuegos");
                add("Crear una lista de objetos de los videojuegos de la tabla videojuegos.");
                add("Pasar la información de la lista a ficheros XML por década.");
                add("Consultar fichero XML.");
                add("Finalizar");
            }
        };

        /*La clase Menu permite imprimir el menú a partir de los datos de un ArrayList<String>
            y utilizar métodos para control de rango*/
        Menu miMenu = new Menu(misOpciones);

        System.out.println("\n\n*******************************************************************************************************");
        /* Solo sale del While cuando se selecciona una opción correcta en rango y tipo*/
        do {
            miMenu.printMenu();

            /*La clase ControlData permite hacer un control de tipo leído*/
            try {
                opcion = ControlData.lerByte(sc);
                /*miMenu.rango() lanza una excepción propia en el caso de que 
                el parámetro opcion esté fuera del rango posible */
                miMenu.rango(opcion);
                correcta = true;
            } catch (NumeroFueraRangoException e) {//Excepción personalizada
                System.out.println(e.getMessage());
                correcta = false;
            }

        } while (!correcta);

        return opcion;
    }

}
