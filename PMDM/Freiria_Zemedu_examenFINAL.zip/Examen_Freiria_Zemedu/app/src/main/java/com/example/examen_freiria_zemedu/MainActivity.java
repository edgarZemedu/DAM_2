package com.example.examen_freiria_zemedu;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    Button boton1, boton2, boton3;
    CheckBox checkBox1, checkBox2, checkBox3;

    public static List<ListaAlbums> listaAlbums;
    public static List<ListaAlbums> listadoRock;
    public static List<ListaAlbums> listadoBlues;
    public static List<ListaAlbums> listadoJazz;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        boton1 = findViewById(R.id.button1);
        boton2 = findViewById(R.id.button2);
        boton3 = findViewById(R.id.button3);
        checkBox1 = findViewById(R.id.checkBox1);
        checkBox2 = findViewById(R.id.checkBox2);
        checkBox3 = findViewById(R.id.checkBox3);

        cargarDatos();



    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu1, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.itemSimple:
                checkBox1.setVisibility(View.VISIBLE);
                checkBox2.setVisibility(View.VISIBLE);
                checkBox3.setVisibility(View.VISIBLE);
                boton1.setVisibility(View.VISIBLE);
                boton2.setVisibility(View.VISIBLE);
                boton3.setVisibility(View.VISIBLE);
                return true;
            case R.id.itemCompuesta:
                boton1.setVisibility(View.INVISIBLE);
                boton2.setVisibility(View.INVISIBLE);
                boton3.setVisibility(View.INVISIBLE);
                checkBox1.setVisibility(View.VISIBLE);
                checkBox2.setVisibility(View.VISIBLE);
                checkBox3.setVisibility(View.VISIBLE);

                checkBox1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                        if (listaAlbums.contains(listadoRock)) {
                            Toast.makeText(MainActivity.this, "ya esta puesto ROCK!!!", Toast.LENGTH_SHORT).show();
                        } else if (isChecked) {
                            listaAlbums.addAll(listadoRock);
                        }
                        getSupportFragmentManager().beginTransaction().add(R.id.contenedor5,
                                ItemFragment.newInstance()
                        ).commit();
                    }
                });

                checkBox2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                        if (listaAlbums.contains(listadoBlues) || !isChecked ) {
                            Toast.makeText(MainActivity.this, "ya esta puesto BLUES!!!", Toast.LENGTH_SHORT).show();
                        } else
                        if (isChecked) {
                            listaAlbums.addAll(listadoBlues);
                        }
                        getSupportFragmentManager().beginTransaction().add(R.id.contenedor5,
                                ItemFragment.newInstance()
                        ).commit();
                    }
                });
                checkBox3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                        if (listaAlbums.contains(listadoJazz)) {
                            Toast.makeText(MainActivity.this, "ya esta puesto JASS!!!", Toast.LENGTH_SHORT).show();
                        } else
                        if (isChecked) {
                            listaAlbums.addAll(listadoJazz);
                        }
                        getSupportFragmentManager().beginTransaction().add(R.id.contenedor5,
                                ItemFragment.newInstance()
                        ).commit();
                    }
                });

                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void botonRock(View view) {
        listaAlbums = new ArrayList<>();
        if (listaAlbums.contains(listadoRock)) {
            Toast.makeText(this, "ya esta puesto ROCK!!!", Toast.LENGTH_SHORT).show();
        } else
            listaAlbums.addAll(listadoRock);

        getSupportFragmentManager().beginTransaction().add(R.id.contenedor5,
                ItemFragment.newInstance()
        ).commit();
    }

    public void botonBlues(View view) {
        listaAlbums = new ArrayList<>();
        if (listaAlbums.contains(listadoBlues)) {
            Toast.makeText(this, "ya esta puesto BLUES!!!", Toast.LENGTH_SHORT).show();
        } else
            listaAlbums.addAll(listadoBlues);

        getSupportFragmentManager().beginTransaction().add(R.id.contenedor5,
                ItemFragment.newInstance()
        ).commit();
    }

    public void botonJass(View view) {
        listaAlbums = new ArrayList<>();
        if (listaAlbums.contains(listadoJazz)) {
            Toast.makeText(this, "ya esta puesto JASS!!!", Toast.LENGTH_SHORT).show();
        } else
            listaAlbums.addAll(listadoJazz);

        getSupportFragmentManager().beginTransaction().add(R.id.contenedor5,
                ItemFragment.newInstance()
        ).commit();
    }

    private void cargarDatos() {
        listadoRock = new ArrayList<>();

        listadoRock.add(ListaAlbums.newInstance("Abbey Road", "The Beatles", R.drawable.abbeyroad,
                getResources().getString(R.string.abbeyroad)));
        listadoRock.add(ListaAlbums.newInstance("Exile on Main Street", "The Rolling Stones", R.drawable.exileonmainst,
                getResources().getString(R.string.exilesonmainstreet)));
        listadoRock.add(ListaAlbums.newInstance("The Velvet Underground", "The Velvet Underground and Nico", R.drawable.velvetunderground,
                getResources().getString(R.string.velvetunderground)));
        listadoRock.add(ListaAlbums.newInstance("Are You Experienced", "Jimi Hendrix", R.drawable.areyouexperienced,
                getResources().getString(R.string.areyouexperienced)));
        listadoRock.add(ListaAlbums.newInstance("Back in Black", "AC/DC", R.drawable.backinblack,
                getResources().getString(R.string.backinblack)));
        listadoRock.add(ListaAlbums.newInstance("Appetite for Destruction", "Guns N’ Roses", R.drawable.appetitefordestruction,
                getResources().getString(R.string.appetitefordestruction)));
        listadoRock.add(ListaAlbums.newInstance("Led Zeppelin IV", "Led Zeppelin", R.drawable.ledzeppeliniv,
                getResources().getString(R.string.ledzeppeliniv)));


        listadoBlues = new ArrayList<>();
        listadoBlues.add(ListaAlbums.newInstance("Lady Soul", "Aretha Franklin", R.drawable.ladysoul,
                getResources().getString(R.string.ladysoul)));
        listadoBlues.add(ListaAlbums.newInstance("I Never Loved a Man the Way I Love You", "Aretha Franklin", R.drawable.neverloved,
                getResources().getString(R.string.ineverloveda)));
        listadoBlues.add(ListaAlbums.newInstance("What's Going On", "Marvin Gaye", R.drawable.whatsgoingon,
                getResources().getString(R.string.whatsgoingon)));


        listadoJazz = new ArrayList<>();
        listadoJazz.add(ListaAlbums.newInstance("Kind of Blue", "Miles Davis", R.drawable.kindofblue,
                getResources().getString(R.string.kindofblue)));
        listadoJazz.add(ListaAlbums.newInstance("Bitches Brew", "Miles Davis", R.drawable.bitchesbrew,
                getResources().getString(R.string.bitchesbrew)));
        listadoJazz.add(ListaAlbums.newInstance("A Love Supreme", "John Coltrane", R.drawable.alovesupreme,
                getResources().getString(R.string.alovesupreme)));

    }
}